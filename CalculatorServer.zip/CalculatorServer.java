import java.util.*;
import java.io.*;
import java.net.*;

/**
 * This program is a server that receives mathmatical expressions from a client,
 * evaluates the expression, and sends back the results. 
 * 
 */

public class CalculatorServer {

    public static void main(String args[]){
        try{
        ServerSocket ss= new ServerSocket(4444);
        Socket clientSocket= ss.accept();
        DataInputStream dis= new DataInputStream(clientSocket.getInputStream());
        DataOutputStream dos= new DataOutputStream(clientSocket.getOutputStream());

        System.out.println("Client connected");

        String input;
        while(true){
            //wait for input first
            input = dis.readUTF();
            if(input.equals("bye")){
                dos.writeUTF("Closing connection");
                break;

            }

            System.out.println("Equation received: " + input);
            int result;

            //break equation into operand and operation
            StringTokenizer st = new StringTokenizer(input);

            int operand1 = Integer.parseInt(st.nextToken());
            String operation = st.nextToken();
            int operand2 = Integer.parseInt(st.nextToken());
            if (operation.equals("+"))
            {
                result = operand1 + operand2;
            }
            else  if (operation.equals("-"))
            {
                result = operand1 - operand2;
            }
            else if (operation.equals("*"))
            {
                result = operand1 * operand2;
            }
            else if (operation.equals("/") && operand2 != 0)
            {
                result = operand1 / operand2;
            }
            else
            {
                dos.writeUTF("Error from invalid operation or division by 0");
                continue;
            } 

            System.out.println("Sending result... ");
            // now we send result back to client

            dos.writeUTF(Integer.toString(result));
        }

        dis.close();
        dos.close();
        clientSocket.close();
        ss.close();
        
    } catch(Exception e){
        e.printStackTrace();
    }

    }


}
