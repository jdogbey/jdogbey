import java.io.*;
import java.net.*;
/**
 * 
 * This program acts as a client that connects to a server calculator over the network.
 * It sends user input (mathematical expressions) to the server and prints the server's response.
 * 
 * 
 */

public class CalculatorClient{
   // intiliazation for sockat, input, and output streams
    private Socket socket;
    private BufferedReader input; 
    private DataOutputStream out;
    private DataInputStream in;

    public CalculatorClient(){
        try{
            InetAddress ip= InetAddress.getLocalHost();
            socket = new Socket(ip,4444);
            System.out.println("Socket Connected");
            System.out.println("Type in format:  X (operation) Y");
            System.out.println("For example: 10 + 5");
            
            //input from terminal
            input = new BufferedReader(new InputStreamReader(System.in));

            //output sent to server
            out = new DataOutputStream(socket.getOutputStream());

            //input from server
            in = new DataInputStream(socket.getInputStream());
        } catch (UnknownHostException e){
            System.out.println(e.getMessage());
            return;
        } catch (IOException i){
            System.out.println(i.getMessage());
            return;
        }
    // Reads message from input to send to server 
    String line = "";
    while(!line.equals("bye")){
        try{
            line = input.readLine();
            if(line != null && !line.trim().isEmpty()){
                out.writeUTF(line);
                String response= in.readUTF();
                System.out.println("Servers response: "+response);
            } else{
                System.out.println("Empty Input");
            }
        } catch(IOException i){
            System.out.println(i.getMessage());
        }
    }
//closing connection
try{
    input.close();
    out.close();
    socket.close();
    in.close();
} catch (IOException i){
    System.out.println(i.getMessage());
}
    }
public static void main(String args[]){

new CalculatorClient();

}


}

